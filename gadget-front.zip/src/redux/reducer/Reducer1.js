const initialState = {
  favorities: []
};

export const favoritiesReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_TO_FAVORITIES":
      const itemfvr = action.payload;

      // Check if the item already exists in the favorities
      const itemIndex = state.favorities.findIndex((item) => item.id === itemfvr.id);

      if (itemIndex >= 0) {
        // If the item already exists in the favorities, create a new array with updated quantities
        const updatedFavorities = state.favorities.map((item, index) =>
          index === itemIndex ? { ...item, quantity: item.quantity + 1 } : item
        );

        return {
          ...state,
          favorities: updatedFavorities,
        };
      } else {
        // If the item does not exist in the favorities, add the item with a quantity of 1
        const temp = { ...itemfvr, quantity: 1 };
        return {
          ...state,
          favorities: [...state.favorities, temp],
        };
      }

    case "EXT_FAVORITIES":
      const itemext = action.payload;
      const updatedFavorities = state.favorities.filter((item) => item.id !== itemext);
      return {
        ...state,
        favorities: updatedFavorities,
      };

    default:
      return state;
  }
};

export default favoritiesReducer;








  
    

